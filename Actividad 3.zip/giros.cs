using UnityEngine;

public class giros : MonoBehaviour
{
     public Transform sol;  // El primer objeto alrededor del cual rotará el segundo
    public Transform tierra;  // El segundo objeto alrededor del cual rotará el tercero
    public Transform luna;  // El tercer objeto
    public float speed1 = 50f; // Velocidad de rotación del segundo objeto alrededor del primero
    public float speed2 = 30f; // Velocidad de rotación del tercer objeto alrededor del segundo
     public float speed3 = 20f; // Velocidad de rotación del tercer objeto

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
       transform.RotateAround(sol.position, Vector3.forward, speed1 * Time.deltaTime);

        // Rota el tercer objeto alrededor del segundo
        tierra.RotateAround(transform.position, Vector3.forward, speed3 * Time.deltaTime);
        luna.RotateAround(transform.position, Vector3.forward, speed3 * Time.deltaTime);
    }
}

using UnityEngine;

public class Rotar : MonoBehaviour
{
    public float speed = 50f; // Velocidad de rotación
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // Rotamos el objeto alrededor de su eje Z
        transform.Rotate(0, 0, speed * Time.deltaTime);
    }
}
